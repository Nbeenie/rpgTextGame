package gwajae_eun;

public class Ending {
	static void ending() {
		System.out.println("처음 아르바이트의 길에 발을 디딘 " + User.hero_name + "...");
		CafeAlba.time1();
		System.out.println("그 상대하기 어려운 진상손님들을 모두 제압하며 알바왕의 자리에 오르고...");
		CafeAlba.time1();
		System.out.println("온갖 도전과 시행착오 끝에 마침내 창업왕으로서의 성공을 맛보았다...");
		CafeAlba.time1();
		System.out.println(User.hero_name + "은 훌륭히 자신의 가게를 키워냈다!");
		CafeAlba.time1();
		System.out.println("“ “알바왕 김자바”의 이야기, 마침. “");
	}
}
